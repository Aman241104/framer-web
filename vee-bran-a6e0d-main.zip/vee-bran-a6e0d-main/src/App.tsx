import './framer/styles.css'

import NavigationFramerComponent from './framer/section/navigation'
import FooterFramerComponent from './framer/section/footer'
import BackgroundDotsXlFramerComponent from './framer/element/background-dots-xl'
import ScrollArrowFramerComponent from './framer/element/scroll-arrow'
import NotificationFramerComponent from './framer/section-hero/notification'
import AccordionFramerComponent from './framer/section-faq/accordion'
import StatisticFramerComponent from './framer/section-work/statistic'
import TeamCardFramerComponent from './framer/section-team/team-card'
import TestimonialCardFramerComponent from './framer/section-testimonial/testimonial-card'
import LabelFramerComponent from './framer/element/label'
import ServiceCardFramerComponent from './framer/section-service/service-card'
import ServiceSmallFramerComponent from './framer/section-service/service-small'
import ButtonFramerComponent from './framer/button/button'

export default function App() {
  return (
    <div className='flex flex-col items-center gap-3 bg-[rgb(5,_5,_5)]'>
      <NavigationFramerComponent.Responsive/>
      <FooterFramerComponent.Responsive
        T6gFUZS_O={"rgb(0, 74, 173)"}
      />
      <BackgroundDotsXlFramerComponent.Responsive/>
      <ScrollArrowFramerComponent.Responsive
        M25celVi6={"/#works"}
      />
      <NotificationFramerComponent.Responsive/>
      <AccordionFramerComponent.Responsive/>
      <StatisticFramerComponent.Responsive
        lYRUVwspR={"10+"}
        xKpqwDArW={"Brands Automated"}
      />
      <TeamCardFramerComponent.Responsive
        ZpZqU8aeo={"Alif Kepanjen"}
        xJBLV5e6u={"CEO"}
      />
      <TestimonialCardFramerComponent.Responsive
        FruYj3qUZ={"Noam"}
        WGVWrlrPl={"\"VeeBran completely changed the way we approached LinkedIn. From content to outreach, their systems run like clockwork\""}
        eZiFcQlN4={"Founder"}
      />
      <LabelFramerComponent.Responsive
        tWUpRXPNf={"Why VeeBran?"}
      />
      <ServiceCardFramerComponent.Responsive
        LDtNkqyQr={"Personal Branding with AI"}
        olse2q6Lu={"Enhance your LinkedIn presence and influence with AI-driven content and optimization."}
      />
      <ServiceSmallFramerComponent.Responsive
        Hqt2h3vZ2={"AI-Driven Solutions"}
      />
      <ButtonFramerComponent.Responsive
        mZ1MxQ6wB={"Get Started"}
        mhjqxqWNT={"#"}
      />
    </div>
  );
};